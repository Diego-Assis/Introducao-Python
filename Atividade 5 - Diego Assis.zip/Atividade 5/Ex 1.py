cidades = [ "Salinas", "Montes Claros", "Ouro Branco" ]
estados = ( "Minas Gerais", "São Paulo", "Rio de Janeiro", "Santa Catarina" )
paises = { "Brasil": 55, "Estados Unidos": 1, "Portugal": 351 }

print("Tipo: ", type(cidades))
print("Tipo: ", type(estados))
print("Tipo: ", type(paises))