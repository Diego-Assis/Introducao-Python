cidades = []

for i in range(5):
    cidade = input("Informe o nome da cidade:")
    cidades.append(cidade)


for i in range(len(cidades)):
    print(cidades[i])