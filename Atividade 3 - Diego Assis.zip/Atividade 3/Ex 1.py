def conversaoParaCentimetros(metros):
    centimetros = float(metros)*100;
    print("A conversão para centimetros é: ", centimetros)



tamanho = input("Informe os metros para conversão em centimetros: ")
metros = float(tamanho)
conversaoParaCentimetros(metros)